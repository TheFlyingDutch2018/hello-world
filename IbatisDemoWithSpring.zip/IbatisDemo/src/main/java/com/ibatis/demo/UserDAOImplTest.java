package com.ibatis.demo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class UserDAOImplTest {
	
	private static final Logger log = Logger.getLogger(UserDAOImplTest.class);

	public static void main(String[] args) throws SQLException, IOException {

		UserDAOImpl userDAO = new UserDAOImpl();
//		log.info("===============================before getAllUsers()===============================");
//		List<User> userList = userDAO.getAllUsers();
//		for(User user : userList) {
//			log.info("++++++++++++++++++++" + user.toString() + "++++++++++++++++++++");
//		}
//		log.info("===============================after getAllUsers()===============================");
		
//		log.info("===============================before insertUser()===============================");
//		User user = new User();
//		user.setId(1);
//		user.setName("superman");
//		userDAO.insertUser(user);
//		log.info("===============================after insertUser()===============================");
		
//		log.info("===============================before getUserById()===============================");
//		log.info(userDAO.getUserById(1).toString());
//		log.info("===============================after getUserById()===============================");
//		
//		log.info("===============================before getUserByName()===============================");
//		log.info(userDAO.getUserByName("peter").toString());
//		log.info("===============================after getUserByName()===============================");
		
		log.info("===============================before updateUser()===============================");
		Map userMap = new HashMap();
		User tempUser = new User();
		tempUser.setId(1);
		tempUser.setName("Mongo");
		userMap.put("user",tempUser);
		userMap.put("id", tempUser.getId());
		userDAO.updateUser(userMap);
		log.info("===============================after updateUser()===============================");
		
//		log.info("===============================before deleteUserById()===============================");
//		userDAO.deleteUserById(0);
//		log.info("===============================after deleteUserById()===============================");
		
	}

}
