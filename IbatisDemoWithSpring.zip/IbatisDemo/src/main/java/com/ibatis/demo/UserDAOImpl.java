package com.ibatis.demo;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class UserDAOImpl implements UserDAO {
	
//	private SqlMapClient getSqlMapClient() throws IOException{
//		
//		String config = "SqlMapConfig.xml";  
//        Reader reader = Resources.getResourceAsReader(config);  
//        SqlMapClient sqlMap = SqlMapClientBuilder.buildSqlMapClient(reader);
//        return sqlMap;
//	}
	
	private SqlMapClient getSqlMapClient() throws IOException{
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("SpringMVC-servlet.xml");
		
		SqlMapClient sqlMap = (SqlMapClient) ctx.getBean("sqlMapClient");
        return sqlMap;
	}

	public void insertUser(User user) throws SQLException, IOException {

		this.getSqlMapClient().update("insertUser", user);
	}

	public void deleteUserById(int id) throws SQLException, IOException {

		this.getSqlMapClient().delete("deleteUserById", id);
	}

	public void updateUser(Map map) throws SQLException, IOException {

		this.getSqlMapClient().update("updateUser", map);
	}
	
	public User getUserById(int id) throws SQLException, IOException {
		
		return (User) this.getSqlMapClient().queryForObject("getUserById",id);
	}
	
	public User getUserByName(String name) throws SQLException, IOException {
		
		return (User) this.getSqlMapClient().queryForObject("getUserByName", name);
	}

	public List<User> getAllUsers() throws SQLException, IOException {
		
		return this.getSqlMapClient().queryForList("getAllUsers");
	}



}
