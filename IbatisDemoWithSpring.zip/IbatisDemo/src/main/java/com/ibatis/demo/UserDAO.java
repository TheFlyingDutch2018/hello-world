package com.ibatis.demo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public interface UserDAO {

	public void insertUser(User user) throws SQLException, IOException;
	
	public void deleteUserById(int id) throws SQLException, IOException;
	
	public void updateUserById(int id) throws SQLException, IOException;
	
	public User getUserById(int id) throws SQLException, IOException;
	
	public User getUserByName(String name) throws SQLException, IOException;
	
	public List<User> getAllUsers() throws SQLException, IOException;
}
