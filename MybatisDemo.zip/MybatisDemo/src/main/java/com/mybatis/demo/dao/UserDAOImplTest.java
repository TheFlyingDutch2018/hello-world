package com.mybatis.demo.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.mybatis.demo.beans.User;

public class UserDAOImplTest {
	
	private static final Logger log = Logger.getLogger(UserDAOImplTest.class);

	public static void main(String[] args) {

		UserDAOImpl userDAO = new UserDAOImpl();
		
//		log.info("=================================brfore insertUser()=================================");
//		User user = new User(1, "superman");
//		userDAO.insertUser(user);
//		log.info("=================================after insertUser()=================================");
		
		
		log.info("=================================brfore updateUserById()=================================");
		User user = new User(1, "ironman");
		Map userMap = new HashMap();
		userMap.put("user", user);
		userMap.put("id", user.getId());
		userDAO.updateUserById(userMap);
		log.info("=================================after updateUserById()=================================");
		
		
//		log.info("=================================brfore deleteUserById()=================================");
//		userDAO.deleteUserById(1);
//		log.info("=================================after deleteUserById()=================================");
		
		
//		log.info("=================================brfore getUserById()=================================");
//		log.info(userDAO.getUserById(0).toString());
//		log.info("=================================after getUserById()=================================");
		
		
//		log.info("=================================brfore getAllUsers()=================================");
//		List<User> userList = userDAO.getAllUsers();
//		for(User user1 : userList) {
//			log.info(user1);
//		}
//		log.info("=================================after getAllUsers()=================================");

	}

}
