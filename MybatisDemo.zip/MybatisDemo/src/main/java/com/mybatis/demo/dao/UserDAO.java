package com.mybatis.demo.dao;

import java.util.List;
import java.util.Map;

import com.mybatis.demo.beans.User;

public interface UserDAO {
	
	public void insertUser(User user);
	
	public void updateUserById(Map map);
	
	public void deleteUserById(int id);
	
	public User getUserById(int id);
	
	public List<User> getAllUsers();

}
