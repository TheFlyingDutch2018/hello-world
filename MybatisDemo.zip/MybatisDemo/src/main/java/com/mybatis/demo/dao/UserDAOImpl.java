package com.mybatis.demo.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import com.mybatis.demo.beans.User;
import com.mybatis.demo.mapper.UserMapper;
import com.mybatis.demo.tools.MybatisTools;

public class UserDAOImpl implements UserDAO {

	public void insertUser(User user) {

		SqlSession session = MybatisTools.getSession();
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		try {
			mapper.insertUser(user);
			session.commit();
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	public void updateUserById(Map map) {

		SqlSession session = MybatisTools.getSession();
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		try {
			mapper.updateUserById(map);
			session.commit();
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	public void deleteUserById(int id) {

		SqlSession session = MybatisTools.getSession();
		UserMapper mapper = session.getMapper(UserMapper.class);

		try {
			mapper.deleteUserById(id);
			session.commit();
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	public User getUserById(int id) {

		SqlSession session = MybatisTools.getSession();
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		try {
			User user = (User)mapper.getUserById(id);
			session.commit();
			return user;
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

	public List<User> getAllUsers() {

		SqlSession session = MybatisTools.getSession();
		UserMapper mapper = session.getMapper(UserMapper.class);
		
		try {
			List<User> list = mapper.getAllUsers();
			session.commit();
			return list;
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

}
