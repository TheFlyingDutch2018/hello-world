package com.hibernate.demo;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateTest {
	
	private static SessionFactory sessionFactory;
	
	private static Logger log = Logger.getLogger(HibernateTest.class);
	
	static {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		sessionFactory = cfg.buildSessionFactory();
	}
	
	public void testSave(int id, String name) {
		
		User user = new User();
		user.setId(id);
		user.setName(name);
		
		//��һ���µ�session
		Session session = sessionFactory.openSession();
		//��������
		Transaction tx = session.beginTransaction();
		
		log.info("==============================" + this.getClass().getName() + " : testSave() prepare to save user" + "==============================");
		session.save(user);
		log.info("==============================" + this.getClass().getName() + " : testSave() after save user" + "==============================");
		
		//�ύ����
		tx.commit();
		//�ر������ͷ���Դ����һ�������Ĺرգ�
		session.close();
	}
	
	public void testGet(int id) {
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		log.info("==============================" + this.getClass().getName() + " : testGet() prepare to get user" + "==============================");
		User user = session.get(User.class, id);
		log.info("==============================" + this.getClass().getName() + " : testGet() after get user" + "==============================");
		System.out.println(user);
		
		tx.commit();
		session.close();
	}
	
	public static void main(String[] args) {
		
		HibernateTest test = new HibernateTest();
//		test.testSave(3, "David");
		test.testGet(4);
	}

}
