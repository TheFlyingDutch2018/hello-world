package com.hibernate;

import java.util.List;

import org.apache.log4j.Logger;

import com.hibernate.demo.User;

public class UserDAOImplTest {
	
	private static final Logger log = Logger.getLogger(UserDAOImplTest.class);

	public static void main(String[] args) {

		UserDAOImpl userDAO = new UserDAOImpl();
		
//		log.info("=========================before getAllUsers()=========================");
//		List<User> userList = userDAO.getAllUsers();
//		for(User user : userList) {
//			log.info("+++++++++++++++++++++"+user.toString()+"+++++++++++++++++++++");
//		}
//		log.info("=========================after getAllUsers()=========================");
		
//		log.info("=========================before getUserById()=========================");
//		User user = userDAO.getUserById(0);
//		log.info("+++++++++++++++++++++"+user.toString()+"+++++++++++++++++++++");
//		log.info("=========================after getUserById()=========================");
		
//		log.info("=========================before saveUser()=========================");
//		User user = new User();
//		user.setId(5);
//		user.setName("No.5");
//		userDAO.saveUser(user);
//		log.info("=========================after saveUser()=========================");
		
//		log.info("=========================before updateUser()=========================");
//		User user = new User();
//		user.setId(5);
//		user.setName("Fifth");
//		userDAO.updateUser(user);
//		log.info("=========================after updateUser()=========================");
		
		log.info("=========================before deleteUserById()=========================");
		userDAO.deleteUserById(5);
		log.info("=========================after deleteUserById()=========================");
		
	}

}
