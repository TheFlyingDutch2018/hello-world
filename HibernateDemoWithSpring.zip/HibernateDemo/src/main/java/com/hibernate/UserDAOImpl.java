package com.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.demo.User;

public class UserDAOImpl implements UserDAO {
	

	public List<User> getAllUsers() {

		Session session = HibernateUtils.openSession();
		Transaction tx = null;
		
		try {
            tx = session.beginTransaction();

            // ��ʽһ��ʹ��HQL���
            List<User> list = session.createQuery("FROM User").list(); // ʹ��HQL��ѯ

            tx.commit();
            return list;
        } catch (RuntimeException e) {
            tx.rollback();
            throw e;
        } finally {
            session.close();
        }
	}

	public User getUserById(int id) {

		Session session = HibernateUtils.openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			User user = session.get(User.class, id);
			tx.commit();
			return user;
		} catch (RuntimeException e) {
			tx.rollback();
			throw e;
		} finally {
			session.close();
		}
	}

	public void saveUser(User user) {

		Session session = HibernateUtils.openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			session.save(user);
			tx.commit();
		} catch (RuntimeException e) {
			tx.rollback();
			throw e;
		} finally {
			session.close();
		}
	}

	public void updateUser(User user) {

		Session session = HibernateUtils.openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			session.update(user);
			tx.commit();
		} catch (RuntimeException e) {
			tx.rollback();
			throw e;
		} finally {
			session.close();
		}
	}

	public void deleteUserById(int id) {

		Session session = HibernateUtils.openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			Object user = session.get(User.class, id);// Ҫ�Ȼ�ȡ���������
			session.delete(user);// ɾ������ʵ�����
			tx.commit();
		} catch (RuntimeException e) {
			tx.rollback();
			throw e;
		} finally {
			session.close();
		}
	}

}
