package com.ibatis.demo;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class UserDAOImpl implements UserDAO {
	
	private SqlMapClient getSqlMapClient() throws IOException{
		
		String config = "SqlMapConfig.xml";  
        Reader reader = Resources.getResourceAsReader(config);  
        SqlMapClient sqlMap = SqlMapClientBuilder.buildSqlMapClient(reader);
        return sqlMap;
	}

	public void insertUser(User user) throws SQLException, IOException {

		this.getSqlMapClient().update("insertUser", user);
	}

	public void deleteUserById(int id) throws SQLException, IOException {

		this.getSqlMapClient().delete("deleteUserById", id);
	}

	public void updateUserById(int id) throws SQLException, IOException {

		this.getSqlMapClient().update("updateUserById", id);
	}
	
	public User getUserById(int id) throws SQLException, IOException {
		
		return (User) this.getSqlMapClient().queryForObject("getUserById",id);
	}
	
	public User getUserByName(String name) throws SQLException, IOException {
		
		return (User) this.getSqlMapClient().queryForObject("getUserByName", name);
	}

	public List<User> getAllUsers() throws SQLException, IOException {
		
		return this.getSqlMapClient().queryForList("getAllUsers");
	}



}
